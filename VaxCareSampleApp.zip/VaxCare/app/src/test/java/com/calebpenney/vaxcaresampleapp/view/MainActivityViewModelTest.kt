package com.calebpenney.vaxcaresampleapp.view

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.lifecycle.Observer
import com.calebpenney.vaxcaresampleapp.data.api.BookApi
import com.calebpenney.vaxcaresampleapp.data.model.Book
import com.calebpenney.vaxcaresampleapp.data.model.BookStatus
import com.calebpenney.vaxcaresampleapp.data.repository.BookRepository
import junit.framework.TestCase.assertEquals
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.Rule
import org.junit.Test

class MainActivityViewModelTest {
    @get:Rule
    val rule = InstantTaskExecutorRule()

    private var fakeBookList: List<Book> = listOf(
        Book(
            id = 1,
            title = "Jurassic Park",
            author = "Michael Crichton",
            status = BookStatus(
                id = "1",
                displayText = "",
                timeCheckedIn = null,
                timeCheckedOut = null,
                dueDate = null,
            ),
            fee = 0.0,
            lastEdited = "",
        ),
        Book(
            id = 2,
            title = "Andromeda Strain",
            author = "Michael Crichton",
            status = BookStatus(
                id = "2",
                displayText = "",
                timeCheckedIn = null,
                timeCheckedOut = null,
                dueDate = null,
            ),
            fee = 0.0,
            lastEdited = "",
        ),
    )

    private lateinit var dispatcher: CoroutineDispatcher
    private lateinit var viewModel: MainActivityViewModel
    private lateinit var bookRepository: BookRepository
    private lateinit var bookApi: BookApi

    fun setup() {
        dispatcher = StandardTestDispatcher()
        bookRepository = BookRepository(dispatcher, bookApi)
        viewModel = MainActivityViewModel(bookRepository)
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    @Test
    fun refreshBookListSuccess_validateState() = runTest{
        bookApi = object : BookApi {
            override suspend fun getBookList(): List<Book> {
                return fakeBookList
            }
        }

        val testDispatcher = UnconfinedTestDispatcher(testScheduler)
        Dispatchers.setMain(testDispatcher)

        setup()

        val isLoadingValueList = mutableListOf<Boolean>()
        val observer = Observer<Boolean> {
            isLoadingValueList.add(it)
        }
        viewModel.isLoading.observeForever(observer)
        viewModel.refreshBookList()
        advanceUntilIdle()

        assertEquals(MainActivityUiState(fakeBookList, null), viewModel.uiState.value)
        assertEquals(mutableListOf(false, true, false), isLoadingValueList)
        assertEquals(null, viewModel.errorMessage.value)

        viewModel.isLoading.removeObserver(observer)
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    @Test
    fun refreshBookListFailure_validateState() = runTest{
        bookApi = object : BookApi {
            override suspend fun getBookList(): List<Book> {
                throw Exception()
            }
        }

        val testDispatcher = UnconfinedTestDispatcher(testScheduler)
        Dispatchers.setMain(testDispatcher)

        setup()

        val isLoadingValueList = mutableListOf<Boolean>()
        val observer = Observer<Boolean> {
            isLoadingValueList.add(it)
        }
        viewModel.isLoading.observeForever(observer)
        viewModel.refreshBookList()
        advanceUntilIdle()

        assertEquals(MainActivityUiState(emptyList(), null), viewModel.uiState.value)
        assertEquals(mutableListOf(false, true, false), isLoadingValueList)
        assertEquals("Failed to load books from server", viewModel.errorMessage.value)

        viewModel.isLoading.removeObserver(observer)
    }
}