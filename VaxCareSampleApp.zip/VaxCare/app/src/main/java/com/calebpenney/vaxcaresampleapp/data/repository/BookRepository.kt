package com.calebpenney.vaxcaresampleapp.data.repository

import com.calebpenney.vaxcaresampleapp.data.api.BookApi
import com.calebpenney.vaxcaresampleapp.data.model.Book
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.withContext
import javax.inject.Inject

sealed class BookListResult {
    data class Success(val bookList: List<Book>): BookListResult()
    data class Failure(val message: String, val error: Exception): BookListResult()
}

class BookRepository @Inject constructor(
    private val dispatcher: CoroutineDispatcher,
    private val bookApi: BookApi,
) {
    private val _bookListFlow: MutableStateFlow<List<Book>> = MutableStateFlow(emptyList())
    val bookListFlow: Flow<List<Book>> = _bookListFlow

    suspend fun updateBooks(): BookListResult {
        return withContext(dispatcher) {
            try {
                val bookList = bookApi.getBookList()
                _bookListFlow.value = bookList
                BookListResult.Success(bookList)
            } catch (exception: Exception) {
                BookListResult.Failure("Failed to load books from server", exception)
            }
        }
    }
}