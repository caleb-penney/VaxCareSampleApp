package com.calebpenney.vaxcaresampleapp.view

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.calebpenney.vaxcaresampleapp.data.model.Book
import com.calebpenney.vaxcaresampleapp.data.repository.BookListResult
import com.calebpenney.vaxcaresampleapp.data.repository.BookRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class MainActivityViewModel @Inject constructor(
    private val bookRepository: BookRepository,
) : ViewModel() {
    private val _isLoading: MutableLiveData<Boolean> = MutableLiveData(false)
    val isLoading: LiveData<Boolean> = _isLoading

    private val _errorMessage: MutableLiveData<String?> = MutableLiveData(null)
    val errorMessage: LiveData<String?> = _errorMessage

    private val _uiState: MutableStateFlow<MainActivityUiState> =
        MutableStateFlow(
            MainActivityUiState(
                emptyList(),
                selectedBook = null,
            )
        )
    val uiState: StateFlow<MainActivityUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            bookRepository.bookListFlow.collect { latestBookList ->
                _uiState.value =
                    MainActivityUiState(latestBookList, selectedBook = null)
            }
        }
    }

    fun refreshBookList() {
        viewModelScope.launch {
            _isLoading.value = true
            when (val result = bookRepository.updateBooks()) {
                is BookListResult.Failure -> {
                    _isLoading.value = false
                    _errorMessage.value = result.message
                }
                is BookListResult.Success -> {
                    _isLoading.value = false
                    _errorMessage.value = null
                }
            }
        }
    }

    fun onBackPressed() {
        _uiState.update { currentState ->
            currentState.copy(
                selectedBook = null,
            )
        }
    }

    fun onBookClicked(book: Book) {
        _uiState.update { currentState ->
            currentState.copy(
                selectedBook = book,
            )
        }
    }
}