package com.calebpenney.vaxcaresampleapp.view

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.calebpenney.vaxcaresampleapp.ui.theme.VaxCareSampleAppTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    private val viewModel: MainActivityViewModel by viewModels()

    private val onBackPressedCallback = object : OnBackPressedCallback(true) {
        override fun handleOnBackPressed() {
            viewModel.onBackPressed()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        onBackPressedDispatcher.addCallback(onBackPressedCallback)
        viewModel.refreshBookList()
        enableEdgeToEdge()
        setContent {
            VaxCareSampleAppTheme {
                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(MaterialTheme.colorScheme.background),
                ) { innerPadding ->
                    Box(modifier = Modifier.padding(innerPadding)) {
                        val uiState =
                            viewModel.uiState.collectAsStateWithLifecycle(this@MainActivity).value
                        MainActivityScreen(
                            uiState,
                            isLoading = viewModel.isLoading.observeAsState().value ?: false,
                            errorMessage = viewModel.errorMessage.observeAsState().value,
                            onBookClicked = { book ->
                                viewModel.onBookClicked(book)
                            },
                            onRefreshBookList = {
                                viewModel.refreshBookList()
                            }
                        )
                    }
                }
            }
        }
    }
}