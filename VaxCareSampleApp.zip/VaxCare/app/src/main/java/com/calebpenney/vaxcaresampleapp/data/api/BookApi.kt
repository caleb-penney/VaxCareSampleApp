package com.calebpenney.vaxcaresampleapp.data.api

import com.calebpenney.vaxcaresampleapp.data.model.Book
import retrofit2.http.GET

private const val BOOK_API_URL = "android-test-vaxcare/27bd7ab7d0381f867723225145694e93/raw/c530190f575aaac1ab8d5c416b2da9553be422fe/local-database2.json"

interface BookApi {
    @GET(BOOK_API_URL)
    suspend fun getBookList(): List<Book>
}