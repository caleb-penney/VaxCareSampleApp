package com.calebpenney.vaxcaresampleapp

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class VaxCareSampleApplication : Application()