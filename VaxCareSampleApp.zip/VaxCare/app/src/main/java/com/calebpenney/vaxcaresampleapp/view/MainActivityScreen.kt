package com.calebpenney.vaxcaresampleapp.view

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.PreviewLightDark
import androidx.compose.ui.unit.dp
import com.calebpenney.vaxcaresampleapp.data.model.Book
import com.calebpenney.vaxcaresampleapp.data.model.BookStatus
import com.calebpenney.vaxcaresampleapp.ui.theme.VaxCareSampleAppTheme

data class MainActivityUiState(
    val bookList: List<Book>,
    val selectedBook: Book? = null,
)

@Composable
fun MainActivityScreen(
    uiState: MainActivityUiState,
    isLoading: Boolean = false,
    errorMessage: String? = null,
    onBookClicked: (Book) -> Unit,
    onRefreshBookList: () -> Unit,
) {
    PullToRefreshBox(
        isRefreshing = isLoading,
        onRefresh = { onRefreshBookList() },
        modifier = Modifier.fillMaxSize()
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            if (uiState.selectedBook == null) {
                BookListScreen(uiState, onBookClicked)
            } else {
                BookDetailScreen(uiState.selectedBook)
            }
            if (!errorMessage.isNullOrEmpty()) {
                Text(
                    text = errorMessage,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.errorContainer)
                        .padding(16.dp),
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onErrorContainer,
                )
            }
        }
    }
}

@PreviewLightDark
@Composable
private fun MainActivityScreenLoadingPreview() {
    VaxCareSampleAppTheme {
        val bookList = listOf(
            Book(
                id = 1,
                title = "Jurassic Park",
                author = "Michael Crichton",
                status = BookStatus(
                    id = "1",
                    displayText = "",
                    timeCheckedIn = null,
                    timeCheckedOut = null,
                    dueDate = null,
                ),
                fee = 0.0,
                lastEdited = "",
            ),
            Book(
                id = 2,
                title = "Andromeda Strain",
                author = "Michael Crichton",
                status = BookStatus(
                    id = "2",
                    displayText = "",
                    timeCheckedIn = null,
                    timeCheckedOut = null,
                    dueDate = null,
                ),
                fee = 0.0,
                lastEdited = "",
            ),
        )
        MainActivityScreen(
            uiState = MainActivityUiState(bookList),
            isLoading = true,
            errorMessage = null,
            onBookClicked = {},
            onRefreshBookList = {}
        )
    }
}

@PreviewLightDark
@Composable
private fun MainActivityScreenErrorPreview() {
    VaxCareSampleAppTheme {
        val bookList = listOf(
            Book(
                id = 1,
                title = "Jurassic Park",
                author = "Michael Crichton",
                status = BookStatus(
                    id = "1",
                    displayText = "",
                    timeCheckedIn = null,
                    timeCheckedOut = null,
                    dueDate = null,
                ),
                fee = 0.0,
                lastEdited = "",
            ),
            Book(
                id = 2,
                title = "Andromeda Strain",
                author = "Michael Crichton",
                status = BookStatus(
                    id = "2",
                    displayText = "",
                    timeCheckedIn = null,
                    timeCheckedOut = null,
                    dueDate = null,
                ),
                fee = 0.0,
                lastEdited = "",
            ),
        )
        MainActivityScreen(
            uiState = MainActivityUiState(bookList),
            isLoading = false,
            errorMessage = "Error loading books",
            onBookClicked = {},
            onRefreshBookList = {}
        )
    }
}