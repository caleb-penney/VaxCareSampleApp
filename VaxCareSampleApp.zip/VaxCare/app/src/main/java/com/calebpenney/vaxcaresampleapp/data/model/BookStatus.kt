package com.calebpenney.vaxcaresampleapp.data.model

import com.squareup.moshi.JsonClass

/*
{"id":1,"displayText":"OnShelf","timeCheckedIn":"2021-10-15T09:00"},
{"id":0,"displayText":"CheckedOut","timeCheckedOut":"2024-08-15T03:12","dueDate":"2024-10-15T00:00"}
 */

@JsonClass(generateAdapter = true)
data class BookStatus(
    val id: String,
    val displayText: String,
    val timeCheckedIn: String? = null,
    val timeCheckedOut: String? = null,
    val dueDate: String? = null,
)