package com.calebpenney.vaxcaresampleapp.view

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.PreviewLightDark
import androidx.compose.ui.unit.dp
import com.calebpenney.vaxcaresampleapp.data.model.Book
import com.calebpenney.vaxcaresampleapp.data.model.BookStatus
import com.calebpenney.vaxcaresampleapp.ui.theme.VaxCareSampleAppTheme

@Composable
fun BookListScreen(
    uiState: MainActivityUiState,
    onBookClicked: (Book) -> Unit = {},
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Spacer(modifier = Modifier.height(8.dp))
        uiState.bookList.forEach { book ->
            BookItem(book, onItemClicked = { onBookClicked(book) })
        }
        Spacer(modifier = Modifier.height(8.dp))
    }
}

@Composable
private fun BookItem(book: Book, onItemClicked: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        onClick = onItemClicked
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Text(
                text = book.title,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = book.author, style = MaterialTheme.typography.bodyLarge)
        }
    }
}

@PreviewLightDark
@Composable
private fun BookListScreenPreview() {
    VaxCareSampleAppTheme {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
        ) {
            val bookList = listOf(
                Book(
                    id = 1,
                    title = "Jurassic Park",
                    author = "Michael Crichton",
                    status = BookStatus(
                        id = "1",
                        displayText = "",
                        timeCheckedIn = null,
                        timeCheckedOut = null,
                        dueDate = null,
                    ),
                    fee = 0.0,
                    lastEdited = "",
                ),
                Book(
                    id = 2,
                    title = "Andromeda Strain",
                    author = "Michael Crichton",
                    status = BookStatus(
                        id = "2",
                        displayText = "",
                        timeCheckedIn = null,
                        timeCheckedOut = null,
                        dueDate = null,
                    ),
                    fee = 0.0,
                    lastEdited = "",
                ),
                Book(
                    id = 3,
                    title = "The Stand",
                    author = "Stephen King",
                    status = BookStatus(
                        id = "3",
                        displayText = "",
                        timeCheckedIn = null,
                        timeCheckedOut = null,
                        dueDate = null,
                    ),
                    fee = 0.0,
                    lastEdited = "",
                ),
                Book(
                    id = 4,
                    title = "The Master and Margarita",
                    author = "Mikhail Bulgakov",
                    status = BookStatus(
                        id = "4",
                        displayText = "",
                        timeCheckedIn = null,
                        timeCheckedOut = null,
                        dueDate = null,
                    ),
                    fee = 0.0,
                    lastEdited = "",
                )
            )
            BookListScreen(MainActivityUiState(bookList))
        }
    }
}