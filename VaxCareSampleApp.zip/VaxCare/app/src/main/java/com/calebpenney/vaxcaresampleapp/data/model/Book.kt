package com.calebpenney.vaxcaresampleapp.data.model

import com.squareup.moshi.JsonClass

/*
{
    "id": 7,
    "title": "Hello World!",
    "author": "TheNewBoston",
    "status": {"id":1,"displayText":"OnShelf","timeCheckedIn":"2020-04-15T02:34"},
    "fee": 12,
    "lastEdited": "2020-04-15T02:34:00.00Z"
  }
 */

@JsonClass(generateAdapter = true)
data class Book(
    val id: Int,
    val title: String,
    val author: String,
    val status: BookStatus,
    val fee: Double,
    val lastEdited: String,
)