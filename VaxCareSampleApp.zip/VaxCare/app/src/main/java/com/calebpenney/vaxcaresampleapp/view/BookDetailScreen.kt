package com.calebpenney.vaxcaresampleapp.view

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.PreviewLightDark
import androidx.compose.ui.unit.dp
import com.calebpenney.vaxcaresampleapp.data.model.Book
import com.calebpenney.vaxcaresampleapp.data.model.BookStatus
import com.calebpenney.vaxcaresampleapp.ui.theme.VaxCareSampleAppTheme

@Composable
fun BookDetailScreen(book: Book) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(all = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = book.title,
            style = MaterialTheme.typography.displaySmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )
        BookDetailItem(label = "Author", text = book.author)
        BookDetailItem(label = "Fee", text = "$${book.fee}")
        BookDetailItem(label = "Last edited", text = book.lastEdited)
        Column(modifier = Modifier.fillMaxWidth()) {
            BookDetailItemLabel(label = "Status")
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                BookDetailStatusItem(label = "Display text", text = book.status.displayText)
                book.status.timeCheckedIn?.let {
                    BookDetailStatusItem(label = "Time checked in", text = it)
                }
                book.status.timeCheckedOut?.let {
                    BookDetailStatusItem(label = "Time checked out", text = it)
                }
                book.status.dueDate?.let {
                    BookDetailStatusItem(label = "Due date", text = it)
                }
            }
        }
    }
}

@Composable
private fun BookDetailStatusItem(label: String, text: String) {
    Text(
        text = "$label: $text",
        style = MaterialTheme.typography.bodyLarge,
        color = MaterialTheme.colorScheme.onBackground
    )
}

@Composable
private fun BookDetailItemLabel(label: String) {
    Text(
        text = label,
        style = MaterialTheme.typography.titleLarge,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onBackground
    )
}

@Composable
private fun BookDetailItem(label: String, text: String) {
    Column(modifier = Modifier.fillMaxWidth()) {
        BookDetailItemLabel(label)
        Text(
            text = text,
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onBackground
        )
    }
}

@PreviewLightDark
@Composable
private fun BookDetailScreenPreview() {
    VaxCareSampleAppTheme {
        BookDetailScreen(mockBookList[0])
    }
}

private val mockBookList = listOf(
    Book(
        id = 1,
        title = "The C Programming Language",
        author = "Brian W Kernighan & Dennis M. Ritchie",
        status = BookStatus(
            id = "1",
            displayText = "OnShelf",
            timeCheckedIn = "1978-02-22T20:30"
        ),
        fee = 2.0,
        lastEdited = "1978-02-22T20:30:00.00Z"
    ),
    Book(
        id = 4,
        title = "Hogwarts: A History",
        author = "Nicolas Flammel",
        status = BookStatus(
            id = "0",
            displayText = "CheckedOut",
            timeCheckedOut = "2024-08-15T03:12",
            dueDate = "2024-10-15T00:00"
        ),
        fee = 3.0,
        lastEdited = "1995-10-15T00:00:00.00Z",
    )
)
/*
{
    "id": 1,
    "title": "The C Programming Language",
    "author": "Brian W Kernighan & Dennis M. Ritchie",
    "status": {"id":1,"displayText":"OnShelf","timeCheckedIn":"1978-02-22T20:30"},
    "fee": 2,
    "lastEdited": "1978-02-22T20:30:00.00Z"
  }, {
    "id": 2,
    "title": "Design Patterns",
    "author": "Erich Gamma, Richard Helm, Ralph Johnson & John Vlissides",
    "status": {"id":1,"displayText":"OnShelf","timeCheckedIn":"2019-03-03T07:11"},
    "fee": 5.5,
    "lastEdited": "2019-03-03T07:11:00.00Z"
  }, {
    "id": 3,
    "title": "5 Ingredient Keto Recipes",
    "author": "Sam Dillard",
    "status": {"id":1,"displayText":"OnShelf","timeCheckedIn":"2021-10-15T09:00"},
    "fee": 3,
    "lastEdited": "2021-10-15T09:00:00.00Z"
  }, {
    "id": 4,
    "title": "Hogwarts: A History",
    "author": "Nicolas Flammel",
    "status": {"id":0,"displayText":"CheckedOut","timeCheckedOut":"2024-08-15T03:12","dueDate":"2024-10-15T00:00"},
    "fee": 3,
    "lastEdited": "1995-10-15T00:00:00.00Z"
  }
 */